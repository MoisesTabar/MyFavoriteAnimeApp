# Buenas tardes profesor Amadis

Le adjunto este archivo README para avisarle de que el proyecto entero sobrepasaba los 250mb y por ende no podia subirlo a la plataforma.
Asi que tome las partes mas importantes, el lib, los pubspec, los assets y los json en la carpeta data. Solamente para ver el proyecto tendria que crear un nuevo proyecto de flutter y substituir los archivos correspondientes(lib, pubspec.lock y pubspec.yaml, los assets, los json en la carpeta data).

# Muchas gracias por su compresion, pase buenas tardes