import 'package:flutter/material.dart';
import 'package:series_app/src/widget/moments_slideshow.dart';

class MomentsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: MomentsSlideshow(), 
    );
  }
}