import 'package:flutter/material.dart';
import 'package:series_app/src/app.dart';

void main() => runApp(App());